# Stanley Juma Fintech

Android-ready Flutter fintech MVP.

## Build APK on GitHub
1. Upload the contents of this folder to the repository root.
2. Open **Actions** on GitHub.
3. Select **Build Stanley Juma Fintech APK**.
4. Tap **Run workflow**.
5. When the workflow finishes, open the run and download the **Stanley-Juma-Fintech-APK** artifact.

The workflow automatically generates the missing Android project files before building the APK.

> This MVP is a prototype. Do not connect real money, customer KYC data, or production M-PESA credentials until backend security, compliance, licensing, and payment integration have been completed.
