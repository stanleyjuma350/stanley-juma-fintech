# Stanley Juma Fintech App

A production-oriented MVP source package for a Kenyan digital wallet and lending application.

## Included
- Flutter Android/iOS customer app source
- Login shell and customer dashboard
- Wallet and transaction history
- Loan application flow
- Loan balance and repayment information
- Profile/KYC/security screens
- Mock M-PESA deposit flow
- Local app state for demonstration
- Production integration checklist

## Run
1. Install Flutter 3.x and Android Studio.
2. Open `stanley_juma_app`.
3. Run `flutter pub get`.
4. Run `flutter run` on an Android device/emulator.

## Production work still required
This package deliberately does **not** pretend to connect to financial services. Before live use, add a secure backend, real authentication/OTP, KYC provider, M-PESA Daraja integration, credit scoring, loan ledger, reconciliation, notifications, audit logs, encryption, rate/fee configuration, role-based admin portal, monitoring, backups and Kenyan regulatory/compliance review.

Never put M-PESA consumer keys, database passwords, signing secrets or private credentials in the mobile app.
