-- Starter PostgreSQL schema. Adapt and review with a qualified backend/security engineer.
CREATE TABLE users (
  id UUID PRIMARY KEY,
  phone VARCHAR(20) UNIQUE NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  national_id_hash TEXT,
  kyc_status VARCHAR(30) DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE wallets (
  id UUID PRIMARY KEY,
  user_id UUID UNIQUE REFERENCES users(id),
  currency CHAR(3) DEFAULT 'KES',
  available_balance NUMERIC(18,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE loans (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  principal NUMERIC(18,2) NOT NULL,
  interest_rate NUMERIC(8,4) NOT NULL,
  term_months INT NOT NULL,
  status VARCHAR(30) DEFAULT 'pending',
  outstanding_balance NUMERIC(18,2) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE transactions (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  wallet_id UUID REFERENCES wallets(id),
  type VARCHAR(40) NOT NULL,
  amount NUMERIC(18,2) NOT NULL,
  reference VARCHAR(100) UNIQUE,
  status VARCHAR(30) DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE repayments (
  id UUID PRIMARY KEY,
  loan_id UUID REFERENCES loans(id),
  amount NUMERIC(18,2) NOT NULL,
  due_date DATE NOT NULL,
  paid_at TIMESTAMPTZ,
  status VARCHAR(30) DEFAULT 'pending'
);
CREATE TABLE audit_logs (
  id BIGSERIAL PRIMARY KEY,
  actor_id UUID,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(50),
  entity_id UUID,
  metadata JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);
